// const { now, now } = require("lodash");
const db = require("../models");
const moment = require('moment');
const { QueryTypes, NOW } = require('sequelize')

exports.getAll = async () => {
    try {
        const result = await db.GatepassDetail.findAll({
            order: [["GatepassID", "ASC"]],
        })

        return result
    }
    catch (err) {
        throw err
    }
}

exports.getgatepassdetail = async () => {
    try {
        const query =
        "select * " +
        // "select dmsgatepass.gatepass_id,dmsgatepassdetail.gatepass_detail_id, gatepass_ref,destination, dmsdepartment.department_name, serial_no, dmsgatepass.description as vehicle_no, dmsgatepassdetail.description, product_name, quantity " +
        "FROM public.dmsgatepassdetail " +
        "inner join dmsgatepass on dmsgatepass.gatepass_id = dmsgatepassdetail.gatepass_id " +
        "inner join dmsproduct on dmsproduct.product_id = dmsgatepassdetail.product_id " +
        "inner join dmsdepartment on dmsdepartment.department_id = dmsgatepass.department " +
        "order by dmsgatepass.gatepass_id asc "
    
        const result = await db.sequelize.query(query, {
            type: QueryTypes.SELECT
        })

        console.log("result",result.length)

        let gatepass = []

        gatepass = [
        {
            gatepass_id: result[0].gatepass_id,
            department_name: result[0].department_name,
            destination: result[0].destination,
            driver: result[0].driver,
            sim_ktp: result[0].sim_ktp,
            vehicle: result[0].vehicle,
            vehicle_desc: result[0].vehicle_desc,
            gatepass_ref: result[0].gatepass_ref,
            gatepassdetails: result

        }]

        return gatepass
    } catch (err) {
        throw err
    }
}

exports.getgatepassdetailnew = async () => {
    try {
        const query =
        "select * " +
        // "select dmsgatepass.gatepass_id,dmsgatepassdetail.gatepass_detail_id, gatepass_ref,destination, dmsdepartment.department_name, serial_no, dmsgatepass.description as vehicle_no, dmsgatepassdetail.description, product_name, quantity " +
        "FROM public.dmsgatepassdetail " +
        "inner join dmsgatepass on dmsgatepass.gatepass_id = dmsgatepassdetail.gatepass_id " +
        "inner join dmsproduct on dmsproduct.product_id = dmsgatepassdetail.product_id " +
        "inner join dmsdepartment on dmsdepartment.department_id = dmsgatepass.department " +
        "order by dmsgatepass.gatepass_id asc "
    
        const result = await db.sequelize.query(query, {
            type: QueryTypes.SELECT
        })

        console.log("result",result.length)

        let gatepass = []
        let gatepassdetail = []
        let gatepass_temp = []

        // gatepassdetail = 
        // {
        //     gatepass_id : result[0].gatepass_id
        // }
        // console.log("gatepassdetail",gatepassdetail)
        // gatepass_temp = gatepass_temp.concat(gatepassdetail)
        
        // for(i=0;i<result.length;i++) 
        // {
        //     gatepass[i] = 
        //     [
        //         {
        //             gatepassdetail_id: result[i].gatepass_detail_id
        //         }
        //     ]
        // }

        // gatepass_temp = gatepass_temp.push(gatepass)

        // console.log("gatepass_temp",gatepass_temp)

        for(i=0;i<result.length;i++) {
            gatepass[i] = result[i]
            // console.log("gatepass",gatepass[i])
        }
        gatepassdetail= 
        [
            {
                gatepass_id:result[0].gatepass_id
            }
        ]
        gatepassdetail.push(gatepass)
        console.log("gatepassdetail",gatepassdetail)

        return result
    } catch (err) {
        throw err
    }
}

exports.update = async (id, data) => {
    console.log("data : ",data)
    try {
        const result = await db.GatepassDetail.update(data, {
            where: { GatepassDetailID: id },
        })

        return result
    }
    catch (err) {
        throw err
    }
}

exports.create = async (data) => {
    console.log("data : ",data)
    try {

        var datagatepass = {}

         console.log("data",data.product_id)

        
        // console.log("sim_ktp",data.sim_ktp)
        // GatepassID = "GPS_" + moment(new Date()).format("YYMMDDhhmmss")
        GatepassDetailID = "GPD_" + moment(new Date()).format("YYMMDDhhmmss")
        // datagatepass.Department = data.department_name
        // datagatepass.Destination = data.destination
        // datagatepass.Driver = data.driver
        // datagatepass.SIM_KTP = data.sim_ktp
        // datagatepass.Vehicle = data.vehicle
        // datagatepass.VehicleDesc = data.vehicle_desc

        // console.log("datagatepass",datagatepass)
        var now = new Date()
        console.log("now : ",now)
        // const query =   
        // 'INSERT INTO dmsgatepass(gatepass_id, gatepass_ref, destination, department, reason, driver, sim_ktp, vehicle, vehicle_desc, vehicle_no, approved_by, cancel_by, cancel_date, cancel_reason, status, is_active, created_by, updated_by, "createdAt", "updatedAt") '+
        // "VALUES ('" + data.gatepass_id + "', '" + data.gatepass_ref + "', '" + data.destination + "', '" + data.department_name + "', '" + data.reason + "', '" + data.driver + "', '" + data.sim_ktp + "', '" + data.vehicle + "', '" + data.vehicle_desc + "' , '" + data.vehicle_no + "', '" + data.approved_by + "', '" + data.cancel_by + "', '" + data.cancel_date + "', '" + data.cancel_reason + "', '" + data.status + "', '" + data.is_active + "', '" + data.created_by + "', '" + data.updated_by + "', '" + now + "', '" + now + "') ";
        // "WHERE emp.employee_id = '" + employeeId + "' ";
  
        // console.log("query",query)
        // const result = await db.sequelize.query(query, {
        //     type: QueryTypes.INSERT
        // })

        // const querygatepassdetail =
        // 'INSERT INTO dmsgatepassdetail(gatepass_detail_id, product_id, gatepass_id, serial_no, description, quantity, satuan, remark, is_active, created_by, updated_by, "createdAt", "updatedAt") ' +
        // "VALUES ('" + GatepassDetailID + "', '" + data.gatepassdetails[0].product_id +"', '" + GatepassID + "', '22414', 'BM 2233 BG', '3', 'PCS', 'Yes', 'Y', 'Admin', 'Admin', '2023-07-12T01:50:03.267Z', '2023-07-12T01:50:03.267Z')"
        // // "WHERE emp.employee_id = '" + employeeId + "' ";
  
        // console.log("query",querygatepassdetail)
        // const resultgatepassdetail = await db.sequelize.query(querygatepassdetail, {
        //     type: QueryTypes.INSERT
        // })

        let gatepassdetailsid_temp
        for(i=0;i<data.length;i++) {
        gatepassdetailsid_temp=GatepassDetailID+i
        console.log("gatepassdetailsid_temp",gatepassdetailsid_temp)
        const querygatepassdetail =
        'INSERT INTO dmsgatepassdetail(gatepass_detail_id, product_id, gatepass_id, serial_no, description, quantity, satuan, remark, is_active, created_by, updated_by, "createdAt", "updatedAt") ' +
        "VALUES ('" + gatepassdetailsid_temp + "', '" + data[i].product_id +"', '" + data[i].gatepass_id + "', '" + data[i].serial_no + "', '" + data[i].description + "', '" + data[i].quantity + "', '" + data[i].satuan + "', '" + data[i].remark + "', '" + data[i].is_active + "', '" + data[i].created_by + "', '" + data[i].updated_by + "', '" + now + "', '" + now + "')"
        // "WHERE emp.employee_id = '" + employeeId + "' ";

        console.log('querygatepassdetail-------------------->', querygatepassdetail)
  
        console.log("query",querygatepassdetail)
        const resultgatepassdetail = await db.sequelize.query(querygatepassdetail, {
            type: QueryTypes.INSERT
        })
            // console.log("gatepass",gatepass[i])
        }
        // datagatepass.GatepassRef = data.gatepass_ref


        //const resultgatepass = await db.Gatepass.create(datagatepass)
        // //console.log("datagatepassdetail",datagatepassdetail)
        // datagatepassdetail.GatepassDetailID = "GPD_" + moment(new Date()).format("YYMMDDhhmmss")

        // //console.log("Received gatepass data:", datagatepass);

        // const resultgatepassdetail = await db.GatepassDetail.create(datagatepassdetail)
        // return {datagatepassdetail, datagatepass}
    }
    catch (err) {
        throw err
    }
}

exports.delete = async (id) => {
    try {
        const result = await db.GatepassDetail.destroy({
            where: {
                GatepassDetailID: id,
            },
        })

        return result
    }
    catch (err) {
        throw err
    }
}

exports.getById = async (id) => {
    try {
      const result = await db.GatepassDetail.findByPk(id)
  
      return result
    }
    catch (err) {    
      throw err
    }
  }
