module.exports = (sequelize, DataTypes) => {
    const Gatepass = sequelize.define(
        "Gatepass",
        {
            GatepassID: {
                type: DataTypes.STRING(20),
                primaryKey: true,
                allowNull: false,
                field: "gatepass_id",
                autoIncrement: false,
                validate: {
                    notEmpty: true,
                },
            },
            GatepassRef: {
                type: DataTypes.STRING(20),
                allowNull: true,
                field: "gatepass_ref",
                validate: {
                    notEmpty: false,
                },
            },
            Destination: {
                type: DataTypes.STRING(50),
                allowNull: true,
                field: "destination",
                validate: {
                    notEmpty: false,
                },
            },
            Department: {
                type: DataTypes.STRING(50),
                allowNull: true,
                field: "department",
                validate: {
                    notEmpty: false,
                },
            },
            Reason: {
                type: DataTypes.STRING(100),
                allowNull: true,
                field: "reason",
                validate: {
                    notEmpty: false,
                },
            },
            Driver: {
                type: DataTypes.STRING(50),
                allowNull: true,
                field: "driver",
                validate: {
                    notEmpty: false,
                },
            },
            SIM_KTP: {
                type: DataTypes.STRING(20),
                allowNull: true,
                field: "sim_ktp",
                validate: {
                    notEmpty: false,
                },
            },
            Vehicle: {
                type: DataTypes.STRING(20),
                allowNull: true,
                field: "vehicle",
                validate: {
                    notEmpty: false,
                },
            },
            VehicleDesc: {
                type: DataTypes.STRING(50),
                allowNull: true,
                field: "vehicle_desc",
                validate: {
                    notEmpty: false,
                },
            },
            VehicleNo: {
                type: DataTypes.STRING(100),
                allowNull: true,
                field: "vehicle_no",
                validate: {
                    notEmpty: false,
                },
            },
            ApprovedBy: {
                type: DataTypes.STRING(100),
                allowNull: true,
                field: "approved_by",
                validate: {
                    notEmpty: false,
                },
            },
            CancelBy: {
                type: DataTypes.STRING(20),
                allowNull: true,
                field: "cancel_by",
                validate: {
                    notEmpty: false,
                },
            },
            CancelDate: {
                type: DataTypes.DATE,
                allowNull: true,
                field: "cancel_date",
                validate: {
                    notEmpty: false,
                },
            },
            CancelReason: {
                type: DataTypes.STRING(50),
                allowNull: true,
                field: "cancel_reason",
                validate: {
                    notEmpty: false,
                },
            },
            Status: {
                type: DataTypes.STRING(10),
                allowNull: true,
                field: "status",
                validate: {
                    notEmpty: false,
                },
            },
            IsActive: {
                type: DataTypes.STRING(1),
                allowNull: true,
                field: "is_active",
                validate: {
                    notEmpty: true,
                },
            },
            CreatedBy: {
                type: DataTypes.STRING(10),
                allowNull: true,
                field: "created_by",
                validate: {
                    notEmpty: true,
                },
            },
            UpdatedBy: {
                type: DataTypes.STRING(10),
                allowNull: true,
                field: "updated_by",
                validate: {
                    notEmpty: false,
                },
            },
            KnownBy: {
                type: DataTypes.STRING(10),
                allowNull: true,
                field: "known_by",
                validate: {
                    notEmpty: false,
                },
            },
        },
        {
            freezeTableName: true,
            tableName: "dmsgatepass",
        }
    );
    return Gatepass;
};